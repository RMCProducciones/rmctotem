<?php

// :default:noticias.html.twig
return array (
);
