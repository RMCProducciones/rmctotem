<?php

// :default:locales.html.twig
return array (
);
