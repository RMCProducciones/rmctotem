php app/console doctrine:generate:entity --entity="AppBundle:Administrador" --fields="email:string(255) password:string(80) salt:string(255) nombres:string(255) apellidos:string(255) fecha_creacion:datetime"

php app/console doctrine:generate:entity --entity="AppBundle:Categoria" --fields="nombre:string(255) fecha_creacion:datetime"

php app/console doctrine:generate:entity --entity="AppBundle:Local" --fields="categoria:integer nombre:string(255) nivel:integer local:string(20) telefono:string(50) horario:string(30) logo:string(255) imagen:string(255) nit:string(15) arrendatario:string(255) fecha_modificacion:datetime fecha_creacion:datetime"

